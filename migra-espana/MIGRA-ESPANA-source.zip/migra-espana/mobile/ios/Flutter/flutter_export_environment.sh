#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/tmp/claude-0/-home-user-speaking-pretest/5a3b1dc5-2ecf-5e05-b3bd-560f45e9ce78/scratchpad/sdk/flutter"
export "FLUTTER_APPLICATION_PATH=/home/user/speaking-pretest/migra-espana/mobile"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=/home/user/speaking-pretest/migra-espana/mobile/ios/Flutter/ephemeral/Packages/.packages/FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=0.1.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
